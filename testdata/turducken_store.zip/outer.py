outer = 1
